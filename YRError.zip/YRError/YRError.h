//
//  YR_NSError.h
//  MoveService
//
//  Created by Luck on 17/3/22.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 错误码

 - YRErrorCode_lackParam:  缺少参数
 - YRErrorCode_fialParmam: 参数错误
 - YRErrorCode_NotReachable: 没有网络
 */
typedef NS_ENUM(NSUInteger,YRErrorCode) {
    YRErrorCode_lackParam               = 4000,
    YRErrorCode_fialParmam              = 4001,
    YRErrorCode_NotReachable            = 4002,
};


@interface YRError : NSObject

/**
 *  定制一个Error

 @param code 错误码
 @param dic  错误详细信息
 @return NSError
 */
+ (NSError *)YRError:(NSError **)error Code:(YRErrorCode)code userInfo:(NSDictionary *)dic;

/**
 * 将NSError转化为错误信息 String

 @param  error 错误
 @return 错误详细信息String
 */
+ (NSString *)transformErrorToString:(NSError *)error;

/**
 * 将错误码转化为错误信息

 @param code 错误码
 @return 错误信息
 */
+ (NSString * )transformCodeToString:(YRErrorCode)code;

@end













