//
//  YR_NSError.m
//  MoveService
//
//  Created by Luck on 17/3/22.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import "YRError.h"

static NSDictionary *errorDictionary = nil;

@implementation YRError

+ (void)initialize
{
    if (self == [YRError class])
    {
        errorDictionary = @{
                            @(YRErrorCode_lackParam)            :@"参数缺少",
                            @(YRErrorCode_fialParmam)           :@"参数错误",
                            @(YRErrorCode_NotReachable)         :@"没有网络",
                            };
    }
}

+ (NSError *)YRError:(NSError **)error Code:(YRErrorCode)code userInfo:(NSDictionary *)dic
{
    *error = [NSError errorWithDomain:errorDictionary[@(code)]
                                code:code
                            userInfo:dic];
    return *error;
}

+ (NSString *)transformErrorToString:(NSError *)error
{
    NSDictionary * errorDict = error.userInfo;
    
    NSData * userInfoData = [NSJSONSerialization dataWithJSONObject:errorDict options:NSJSONWritingPrettyPrinted error:nil];
    
    NSString * errorStr = [[NSString alloc]initWithData:userInfoData encoding:NSUTF8StringEncoding];
    
    return errorStr;
}

+ (NSString * )transformCodeToString:(YRErrorCode)code{
    return errorDictionary[@(code)];
}

@end








