//
//  UIColor+YR_Color.h
//  MoveService
//
//  Created by Luck on 17/3/14.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (YR_Color)

/**
 * 十六进制颜色

 @param color 十六进制字符串
 @param alpha 透明度
 @return UIColor *
 */
+ (UIColor *)colorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

/**
 * 十六进制颜色

 @param color 十六进制字符串
 @return UIColor *
 */
+ (UIColor *)colorWithHexString:(NSString *)color;

@end
