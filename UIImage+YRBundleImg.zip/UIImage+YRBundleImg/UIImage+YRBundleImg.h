//
//  UIImage+YRBundleImg.h
//  MoveService
//
//  Created by Luck on 17/4/1.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (YRBundleImg)

/**
 *  使用Runtime 方法替换 (imageYRName 交换 imageYRBundleName)
 */
+ (UIImage * )imageYRName:(NSString * )imageName;

/**
 *  使用Runtime 方法替换 (imageYRName 交换 imageYRBundleName)
 */
+ (UIImage * )imageYRBundleName:(NSString *)imageName;

@end












