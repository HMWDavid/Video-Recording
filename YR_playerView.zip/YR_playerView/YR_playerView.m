//
//  YR_playerView.m
//  videoTest
//
//  Created by Luck on 17/1/17.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import "YR_playerView.h"


#define YR_footerView_Height   50 //底部视图的高
#define YR_playerBtn_W         45 //开始/暂停按钮的高
#define YR_playerBtn_H         45 //开始/暂停按钮的宽
#define YR_TimeLab_W           50 //显示视频时间Label 的宽
#define YR_TimeLab_H           45 //显示视频时间Label 的高

@interface YR_playerView ()<CAAnimationDelegate>
{
    dispatch_source_t _GCDtimer;//定时器
}

/**
 *  播放的总时长
 */
@property (nonatomic,assign)CGFloat sumPlayOperation;

//滑块是否在屏幕中
@property (nonatomic,assign)BOOL isShowSlider;

//是否在动画
@property (nonatomic,assign)BOOL isAnimation;

//资源路径
@property (nonatomic,strong)NSURL * resourcePath;

//显示时间
@property (nonatomic,strong)UILabel * timeLab;

@end

@implementation YR_playerView

- (void)dealloc
{
    [self removeObserverFromPlayerItem:self.player.currentItem];
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (instancetype)initWithFrame:(CGRect)frame resourcePath:(NSURL * )resourcePath
{
    self = [super initWithFrame:frame];
    if (self) {
        //AVPlayer的后台播放方法
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        NSError *err = nil;
        [audioSession setCategory :AVAudioSessionCategoryPlayback error:&err];

        [self addGenstureRecognizer];//添加点击手势
        self.resourcePath = resourcePath;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(PlayerItemDidPlayToEndTime) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    }
    
    return self;
}

- (instancetype)initWithResourcePath:(NSURL * )resourcePath{
    
    self = [super init];
    
    if (self) {
        //AVPlayer的后台播放方法
        AVAudioSession *audioSession = [AVAudioSession sharedInstance];
        NSError *err = nil;
        [audioSession setCategory :AVAudioSessionCategoryPlayback error:&err];

        
        [self addGenstureRecognizer];//添加点击手势
        
        self.resourcePath = resourcePath;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(PlayerItemDidPlayToEndTime) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    }
    
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    NSLog(@",resourcePath resourcePath = %@",self.resourcePath);

    //设置播放页面的大小
    self.PlayerLayer.frame = self.bounds;
}

//开始播放
- (void)startPlayer{
    
    if (_GCDtimer==nil) {
        
        [self createGCDTime];
    }else{
        if (!self.isPlayer) {
            dispatch_resume(_GCDtimer);
        }
    }
    
    [self.player play];
    self.isPlayer = YES;
}

//暂停播放
- (void)suspendPlayer{
    [self.player pause];
    dispatch_suspend(_GCDtimer);
    self.isPlayer = NO;
}

#pragma mark - 开始/暂停
- (void)playerBtnClick:(UIButton * )sender{
    sender.selected=!sender.selected;
    sender.selected?[self suspendPlayer]:[self startPlayer];
    [sender setTitle:sender.selected?@"播放":@"暂停" forState:UIControlStateNormal];
}

#pragma mark - 点击手势响应函数
- (void)showSliderProgress:(UITapGestureRecognizer *)tap{
    if (tap.numberOfTapsRequired ==1) {//单击
        
        if (!self.isAnimation) {//是否在动画中
            
            [self startAnimation:self.footerView recovery:self.isShowSlider];
        }
        
        self.progressSlider.value = CMTimeGetSeconds(self.player.currentItem.currentTime) / CMTimeGetSeconds(self.player.currentItem.duration);
        
    }else if (tap.numberOfTapsRequired == 2){//双击
        self.playerBtn.selected = !self.playerBtn.selected;
        self.playerBtn.selected?[self suspendPlayer]:[self startPlayer];
        [self.playerBtn setTitle:self.playerBtn.selected?@"播放":@"暂停"forState:UIControlStateNormal];
    }
}

#pragma mark - 滑动条响应事件
- (void)startChangeProgress:(UISlider *)sender{
    
    if (_GCDtimer==nil) {
        [self createGCDTime];
    }
    
    self.sumPlayOperation = self.player.currentItem.duration.value/self.player.currentItem.duration.timescale;
    
    __weak typeof(self) weakSelf = self;
    
    //CMTimeMake(a,b) a表示当前时间，b表示每秒钟有多少帧
    [self.player seekToTime:CMTimeMakeWithSeconds(self.progressSlider.value*self.sumPlayOperation, self.player.currentItem.duration.timescale) completionHandler:^(BOOL finished) {
        
        [weakSelf startPlayer];
        
        weakSelf.playerBtn.selected = YES;
        
        [weakSelf.playerBtn setTitle:@"暂停" forState:UIControlStateNormal];
    }];
}

#pragma mark - 创建一个GCD定时器 时间间隔为0.1秒
- (void)createGCDTime{
    
    NSTimeInterval period = .1f; //设置时间间隔
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    _GCDtimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(_GCDtimer, dispatch_walltime(NULL, 0), period * NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(_GCDtimer, ^{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.progressSlider.value = CMTimeGetSeconds(self.player.currentItem.currentTime) / CMTimeGetSeconds(self.player.currentItem.duration);
        });
    });
    
    dispatch_resume(_GCDtimer);
}

#pragma mark- 添加手势
/**
 *  添加点按手势，点按时聚焦
 */
- (void)addGenstureRecognizer {
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showSliderProgress:)];
    
    [self addGestureRecognizer:tapGesture];
    
    UITapGestureRecognizer *doubleTapGR = [[UITapGestureRecognizer alloc] init];
    
    doubleTapGR.cancelsTouchesInView = NO;
    doubleTapGR.delaysTouchesBegan   = NO;
    doubleTapGR.delaysTouchesEnded   = NO;
    doubleTapGR.numberOfTapsRequired = 2;
    doubleTapGR.numberOfTouchesRequired = 1;
    
    [doubleTapGR addTarget:self action:@selector(showSliderProgress:)];
    [self addGestureRecognizer:doubleTapGR];
    
    [tapGesture requireGestureRecognizerToFail : doubleTapGR];
}

//开启动画
- (void)startAnimation:(UIView * )view recovery:(BOOL)recovery{

    NSNumber * startPosition = [NSNumber numberWithFloat:self.bounds.size.height];
    
    NSNumber * endPosition   = [NSNumber numberWithFloat:self.bounds.size.height - YR_footerView_Height/2.0];
    
    //创建一个基本动画
    CABasicAnimation *basic = [CABasicAnimation animation];
    
    basic.delegate = self;
    
    //动画时间
    basic.duration = .5;
    
    //重复次数
    basic.repeatCount = 0;
    
    //keyPath内容是CALayer的可动画Animatable属性
    basic.keyPath  = @"position.y";
    
    basic.removedOnCompletion = NO;
    
    basic.fillMode = kCAFillModeForwards;
    
    //keyPath相应属性的初始值
    basic.fromValue = recovery?endPosition:startPosition;
    
    //keyPath相应属性的结束值
    basic.toValue  = recovery?startPosition:endPosition;
    
    [view.layer addAnimation:basic forKey:nil];
}


/**
 * 动画已经开始
 */
- (void)animationDidStart:(CAAnimation *)anim
{
    NSLog(@"动画已经开始");
    self.isAnimation = YES;
    self.playerBtn.hidden = NO;
}

/**
 * 动画已经结束
 */
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    NSLog(@"动画已经结束");

    if (flag) {
        self.playerBtn.hidden = self.isShowSlider;
        self.isShowSlider = !self.isShowSlider;
        self.isAnimation = NO;
    }
}

#pragma mark - 播放结束
- (void)PlayerItemDidPlayToEndTime{
    NSLog(@"播放结束");
    
    if (_GCDtimer!=nil) {
        dispatch_suspend(_GCDtimer);
    }

    if (self.delegate!=nil&&[self.delegate respondsToSelector:@selector(didPlayerEnd)]) {
        
        [self.delegate didPlayerEnd];
    }
    
    self.playerBtn.selected = YES;
    
    [self.playerBtn setTitle:@"播放" forState:UIControlStateNormal];

    self.isPlayer = NO;

    [self.player seekToTime:kCMTimeZero];
    
    self.progressSlider.value = .0f;
}

#pragma mark - KVO
/** * 给AVPlayerItem添加监控 *
 * @param playerItem AVPlayerItem对象 */
-(void)addObserverToPlayerItem:(AVPlayerItem *)playerItem{
    //监控状态属性，注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态
    [playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    
    //监控网络加载情况属性
    //[playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];
}

/** * 通过KVO监控播放器状态 *
 * @param keyPath 监控属性
 * @param object 监视器
 * @param change 状态改变
 * @param context 上下文 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    //iTem
    if ([keyPath isEqualToString:@"status"]&&[object isKindOfClass:[AVPlayerItem class]]) {
        
        AVPlayerItem *playerItem =object;
        
        AVPlayerStatus status       = [[change objectForKey:@"new"] intValue];
        
        if(status==AVPlayerStatusReadyToPlay){
            self.timeLab.text  = [NSString stringWithFormat:@"%.0f秒",CMTimeGetSeconds(playerItem.duration)];

            NSLog(@"正在播放...，视频总长度:%.2f",CMTimeGetSeconds(playerItem.duration));
        }
    }
    
    /*
     else if([keyPath isEqualToString:@"loadedTimeRanges"]&&[object isKindOfClass:[AVPlayerItem class]])
     {
     NSArray *array=playerItem.loadedTimeRanges;
     CMTimeRange timeRange = [array.firstObject CMTimeRangeValue];//本次缓冲时间范围
     float startSeconds = CMTimeGetSeconds(timeRange.start);
     float durationSeconds = CMTimeGetSeconds(timeRange.duration);
     NSTimeInterval totalBuffer = startSeconds + durationSeconds;//缓冲总长度
     NSLog(@"共缓冲：%.2f",totalBuffer);
     }
     */
}

-(void)removeObserverFromPlayerItem:(AVPlayerItem *)playerItem{
    [playerItem removeObserver:self forKeyPath:@"status"];
   // [playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
}

#pragma mark - 懒加载
- (AVPlayerLayer *)PlayerLayer{
    if (!_PlayerLayer) {
        
        _PlayerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
        
        _PlayerLayer.backgroundColor = [UIColor colorWithRed:243/255.0 green:246/255.0 blue:250/255.0 alpha:1].CGColor;
        
        //设置播放窗口自适应当前视图    （AVLayerVideoGravityResizeAspect 按原来的比例，在视图中显示）
        _PlayerLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        //添加播放视图到self
        [self.layer addSublayer:_PlayerLayer];
        
        [self addSubview:self.footerView];
    }
    return _PlayerLayer;
}

- (AVPlayer *)player{
    if (!_player) {
        //设置播放的项目
        AVPlayerItem *item = [[AVPlayerItem alloc] initWithURL:self.resourcePath];
        
        _player = [[AVPlayer alloc] initWithPlayerItem:item];
        
        //设置播放的默认音量值
        _player.volume = 1.0f;
        
        [self addObserverToPlayerItem:item];
    }
    return _player;
}

- (UIView * )footerView{
    if (!_footerView) {
        _footerView = [[UIView alloc]initWithFrame:CGRectMake(0, self.bounds.size.height - YR_footerView_Height/2.0, self.bounds.size.width, YR_footerView_Height)];
        _footerView.layer.backgroundColor = [UIColor clearColor].CGColor;
        [_footerView addSubview:self.playerBtn];
        [_footerView addSubview:self.progressSlider];
        [_footerView addSubview:self.timeLab];
    }
    
    return _footerView;
}

- (UISlider * )progressSlider{
    if (!_progressSlider) {
        CGFloat slider_X = CGRectGetMaxX(self.playerBtn.frame);
        _progressSlider = [[UISlider alloc]initWithFrame:CGRectMake(slider_X,(YR_footerView_Height - 30)/2.0, self.bounds.size.width - slider_X - YR_TimeLab_W, 30)];
        //设置播放进度的默认值
        _progressSlider.value = 0;
        _progressSlider.minimumValue = 0.f;
        _progressSlider.maximumValue = 1.0;
        [_progressSlider addTarget:self action:@selector(startChangeProgress:) forControlEvents:UIControlEventValueChanged];//设置响应事件
    }
    
    return _progressSlider;
}

- (UIButton * )playerBtn{
    if (!_playerBtn) {
        
        _playerBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, (YR_footerView_Height - YR_playerBtn_H)/2.0, YR_playerBtn_W, YR_playerBtn_H)];
        [_playerBtn setTitle:@"暂停" forState:UIControlStateNormal];
        [_playerBtn addTarget:self action:@selector(playerBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _playerBtn.backgroundColor = [UIColor clearColor];
        _playerBtn.hidden = YES;
    }
    return _playerBtn;
}

- (UILabel * )timeLab{
    if(!_timeLab){
        CGFloat timeLab_X = CGRectGetMaxX(self.progressSlider.frame);

        _timeLab = [[UILabel alloc]initWithFrame:CGRectMake(timeLab_X, (YR_footerView_Height - YR_TimeLab_H)/2.0, YR_TimeLab_W, YR_TimeLab_H)];
        
        _timeLab.textAlignment = NSTextAlignmentCenter;
        _timeLab.textColor     = [UIColor whiteColor];
        
        _timeLab.hidden = YES;
    }
    
    return _timeLab;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
