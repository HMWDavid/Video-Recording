//
//  YR_playerView.h
//  videoTest
//
//  Created by Luck on 17/1/17.
//  Copyright © 2017年 hongmw. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>


@protocol YR_playerViewDelegate <NSObject>

@optional

//播放结束回调
- (void)didPlayerEnd;

@end

@interface YR_playerView : UIView

/**
 * 开始/暂停
 */
@property (nonatomic,strong)UIButton *playerBtn;

/**
 * 底部视图
 */
@property (nonatomic,strong)UIView * footerView;

/**
 *  控制视频播放的控件
 */
@property (strong, nonatomic) UISlider *progressSlider;

/**
 *  声明播放视频的控件属性[既可以播放视频也可以播放音频] 这里播放视频
 */
@property (nonatomic,strong)AVPlayer *player;

/**
 * 播放视频图层
 */
@property (nonatomic,strong)AVPlayerLayer *PlayerLayer;

/**
 * 是否正在播放
 */
@property (nonatomic,assign)BOOL isPlayer;

@property (nonatomic,weak)id<YR_playerViewDelegate>delegate;

/**
 * 自定义初始函数

 @param frame 坐标
 @param resourcePath 资源路径
 @return 实例
 */
- (instancetype)initWithFrame:(CGRect)frame resourcePath:(NSURL * )resourcePath;

/**
 * 自定义初始函数

 @param resourcePath 资源路径
 @return 实例
 */
- (instancetype)initWithResourcePath:(NSURL * )resourcePath;

//开始播放
- (void)startPlayer;

//暂停播放
- (void)suspendPlayer;



@end












